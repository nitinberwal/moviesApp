package com.example.moviesapp.domain

import com.example.moviesapp.data.MoviesApi

class MoviesRepository(private val movieApi:MoviesApi) {

    suspend fun getListOfMovies(searchQuery:String?) =
        movieApi.getListOfMoviews("66dfc6b7", searchQuery, 1)
}