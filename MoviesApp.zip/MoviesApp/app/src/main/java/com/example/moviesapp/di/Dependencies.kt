package com.example.moviesapp.di

import com.example.moviesapp.data.MoviesApi
import com.example.moviesapp.domain.MoviesRepository
import com.example.moviesapp.presentation.MoviewsViewModel
import org.koin.dsl.module
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

val myModule = module {
        single { MoviewsViewModel(get()) } // Replace MyService() with your actual implementation of the service
    single { MoviesRepository(get()) }
    single { provideMoviesApi() }
    }

fun provideMoviesApi():MoviesApi{
    val retrofit: Retrofit = Retrofit.Builder()
        .baseUrl("http://www.omdbapi.com/")
        .addConverterFactory(GsonConverterFactory.create())
//            .addConverterFactory(SimpleXmlConverterFactory.create())
        .build()

    val service:MoviesApi = retrofit.create(MoviesApi::class.java)
    return service
}