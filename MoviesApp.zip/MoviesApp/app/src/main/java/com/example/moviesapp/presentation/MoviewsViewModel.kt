package com.example.moviesapp.presentation

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.moviesapp.data.MoviesUtility.MoviesData
import com.example.moviesapp.domain.MoviesRepository
import kotlinx.coroutines.launch

class MoviewsViewModel(private val movieRepo:MoviesRepository):ViewModel() {

    val liveDataMovieList:MutableLiveData<MoviesData> = MutableLiveData<MoviesData>()

    fun getListOfMovies(searchQuery:String?){
        viewModelScope.launch() {
            liveDataMovieList.value = movieRepo.getListOfMovies(searchQuery = searchQuery)
        }
    }

}