package com.example.moviesapp.data.MoviesUtility

import com.google.gson.annotations.SerializedName

data class MoviesData(
    @SerializedName("Response")val response: String,
    val Search: List<Search>,
    val totalResults: String
)