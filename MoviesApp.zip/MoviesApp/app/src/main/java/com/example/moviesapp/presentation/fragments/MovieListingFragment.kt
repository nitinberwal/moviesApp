package com.example.moviesapp.presentation.fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.RecyclerView
import com.example.moviesapp.R
import com.example.moviesapp.data.MoviesUtility.MoviesData
import com.example.moviesapp.presentation.MoviewsViewModel
import com.example.moviesapp.presentation.adapters.MovieListingAdapter

class MovieListingFragment : Fragment() {

    private val moviewsViewModel:MoviewsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_movie_listing_page, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val rvMovies = view.findViewById<RecyclerView>(R.id.rvMovies)
        rvMovies.adapter = MovieListingAdapter(requireContext())


        initLiveDataObserver()
        view.findViewById<TextView>(R.id.tvSample).setOnClickListener{
            moviewsViewModel.getListOfMovies(null)
        }
    }

    fun initLiveDataObserver(){
        moviewsViewModel.liveDataMovieList.observe(viewLifecycleOwner, moviesObserver)
    }

    private val moviesObserver = Observer<MoviesData>{
        Log.d("nitin", it.toString())
    }

}