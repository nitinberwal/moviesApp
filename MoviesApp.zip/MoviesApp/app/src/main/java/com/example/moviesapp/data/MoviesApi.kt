package com.example.moviesapp.data

import com.example.moviesapp.data.MoviesUtility.MoviesData
import retrofit2.http.GET
import retrofit2.http.Query

interface MoviesApi {

    @GET("http://www.omdbapi.com/")
    fun getListOfMoviews(
        @Query("apikey") apikey:String?,
        @Query("searchQuery") s:String?,
        @Query("page") page:Int
    ): MoviesData?
}