package com.example.moviesapp.presentation.adapters

import android.app.Application
import android.content.Context
import android.media.Image
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.Recycler
import com.example.moviesapp.R
import com.example.moviesapp.data.MoviesUtility.Search

class MovieListingAdapter(private val context: Context):RecyclerView.Adapter<MovieListingAdapter.MovieViewHolder>() {
    var movieList = listOf<Search>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val inflator = LayoutInflater.from(context)
        return MovieViewHolder(inflator, parent)
    }


    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        holder.bind(movieList[position])
    }

    override fun getItemCount(): Int {
        return movieList.size
    }

    class MovieViewHolder(inflater: LayoutInflater, parent: ViewGroup) :
        RecyclerView.ViewHolder(inflater.inflate(R.layout.item_movies_lists, parent, false)) {
        private var mTitleView: TextView? = null
        private var mYearView: TextView? = null
        private var movieImageView: ImageView ?= null


        init {
            mTitleView = itemView.findViewById(R.id.tvTitle)
            mYearView = itemView.findViewById(R.id.tvPostedDate)
            movieImageView = itemView.findViewById(R.id.ivMovies)
        }

        fun bind(movie: Search) {
            mTitleView?.text = movie.Title
            mYearView?.text = movie.Year.toString()


        }

    }
}