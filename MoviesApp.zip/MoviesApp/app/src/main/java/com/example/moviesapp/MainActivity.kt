package com.example.moviesapp

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity


class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.xml.activity_main)
    }
}
